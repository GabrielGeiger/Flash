package com.example.flash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;

public class som extends AppCompatActivity {
private Button btnVoltarsom;
private MediaPlayer som;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_som);

        btnVoltarsom = findViewById(R.id.btnVoltarsom);
        som = MediaPlayer.create(this, R.raw.som);
        som.start();



        btnVoltarsom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

    }
    public void abrirVoltar(){
        Intent janela = new Intent(this, escolha.class);
        startActivity(janela);
        som.stop();
    }
}