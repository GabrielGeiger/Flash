package com.example.flash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

public class teaser extends AppCompatActivity {
private VideoView olhar;
private Button btnVoltarte;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teaser);

        btnVoltarte = findViewById(R.id.btnVoltarsom);
        olhar = findViewById(R.id.olhar);

        Uri caminho = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.teaser);
        olhar.setVideoURI(caminho);
        olhar.start();

        btnVoltarte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirVoltar();
            }
        });

    }
    public void abrirVoltar() {
        Intent janela = new Intent(this, MainActivity.class);
        startActivity(janela);

    }
}